Written and tested using Python 3.6.3
Uses only python standard library code
I worked alone.

Run using: python3 dnsclient.py <hostname>
example: python3 dnsclient.py www.youtube.com
